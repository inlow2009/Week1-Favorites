# Week 2 Vue.js examples 

* v-for 
* forms - checkboxes
* forms - select 
* forms - radio buttons
* .trim
* .number
* validation
* more computed properties
* mapping and filtering
* vue transitions

Live versions here [https://claraj.github.io/vue-week-2-examples](https://claraj.github.io/vue-week-2-examples)